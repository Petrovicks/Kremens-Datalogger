raspiyuv -rgb -o x.rgb -w 480 -h 360 -sa -100 -op 128 -t 0 -p 120,72,480,338
